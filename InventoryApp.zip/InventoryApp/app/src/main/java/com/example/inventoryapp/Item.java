package com.example.inventoryapp;

/**
 * This class models the Item
 */
public class Item {
    //Member variables
    private int _code;
    private String _itemname;
    private int _price;

    /**
     * default constructor
     */
    public Item(){

    }

    /**
     * Constructor with the following  parameters
     * @param code
     * @param itemname
     * @param price
     */
    public Item(int code,String itemname, int price){
        this._code =code;
        this._itemname = itemname;
        this._price =price;
    }

    /**
     * Constructor taking two variables
     * @param itemname
     * @param price
     */
    public  Item(String itemname, int price){
        this._itemname = itemname;
        this._price = price;
    }

    /********Getter and setter methods for each member variable*****/
    public int getCode() {
        return _code;
    }

    public void setCode(int code) {
        this._code = code;
    }

    public String getItemName() {
        return _itemname;
    }

    public void setItemName(String productname) {
        this._itemname = productname;
    }

    public int getPrice() {
        return _price;
    }

    public void setPrice(int quantity) {
        this._price = quantity;
    }
}
